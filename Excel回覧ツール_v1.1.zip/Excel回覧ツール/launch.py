"""Verify protected files before importing application code."""
from pathlib import Path
import hashlib
import json
import tkinter as tk
from tkinter import messagebox

def verify(base):
    manifest = json.loads((base / "integrity.json").read_text(encoding="utf-8"))
    expected = {"launch.py", "app.py", "general.py", "core.py", "excel_engine.py", "requirements.txt", "起動.cmd", "初期セットアップ.cmd"}
    if set(manifest) != expected:
        raise ValueError("保護ファイル一覧が変更されています")
    for name, wanted in manifest.items():
        if hashlib.sha256((base / name).read_bytes()).hexdigest() != wanted:
            raise ValueError(f"本体が変更されています: {name}\n元の配布ZIPから復元してください。社内AIは settings のみ編集できます。")

if __name__ == "__main__":
    try:
        verify(Path(__file__).resolve().parent)
        from app import main
        main()
    except Exception as e:
        root = tk.Tk(); root.withdraw()
        messagebox.showerror("起動できません", str(e)); root.destroy()
        raise SystemExit(1)
