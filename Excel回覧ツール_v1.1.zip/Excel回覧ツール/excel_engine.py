"""Windows Excel COM adapter; no network service or AI calls."""
from __future__ import annotations
from contextlib import contextmanager
import datetime as dt
from pathlib import Path
import shutil
import tempfile
import uuid
from core import (aggregate, digest, ordered_documents, ordered_systems, parse_date,
                  read_json, serial, sheet_rules, source, validate, validate_general, write_json)

@contextmanager
def excel():
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    app = None
    try:
        app = win32com.client.DispatchEx("Excel.Application")
        app.Visible = False
        app.DisplayAlerts = False
        app.EnableEvents = False
        app.AskToUpdateLinks = False
        app.AutomationSecurity = 3
        yield app
    finally:
        if app is not None:
            try:
                app.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()

@contextmanager
def opened(app, path):
    app.AutomationSecurity = 3
    book = app.Workbooks.Open(str(Path(path).resolve()), UpdateLinks=0, ReadOnly=False,
                              Password="", WriteResPassword="", IgnoreReadOnlyRecommended=True,
                              Notify=False, AddToMru=False)
    try:
        if book.ReadOnly:
            raise ValueError(f"出力用コピーを編集できません: {Path(path).name}")
        yield book
    finally:
        book.Close(SaveChanges=False)

def value_at(book, sheet, address):
    c = book.Worksheets(sheet).Range(address)
    return c.MergeArea.Cells(1, 1).Value2

def actual_range(ws):
    cells = ws.Cells
    def find(order, direction):
        return cells.Find(What="*", After=cells(1, 1), LookIn=-4123, LookAt=2,
                          SearchOrder=order, SearchDirection=direction,
                          MatchCase=False, MatchByte=False, SearchFormat=False)
    last_row = find(1, 2)
    bounds = []
    if last_row is not None:
        first_row, first_col, last_col = find(1, 1), find(2, 1), find(2, 2)
        bounds.append((int(first_row.Row), int(first_col.Column), int(last_row.Row), int(last_col.Column)))
        # Merged cells at the boundary may extend beyond Find's populated cell.
        rng = ws.Range(cells(bounds[0][0], bounds[0][1]), cells(bounds[0][2], bounds[0][3]))
        if int(rng.CountLarge) > 20000:
            raise ValueError(f"{ws.Name}: 自動範囲が大きすぎます。帳票の印刷範囲を設定してください")
        for c in rng:
            if c.MergeCells:
                m = c.MergeArea
                bounds.append((int(m.Row), int(m.Column), int(m.Row + m.Rows.Count - 1),
                               int(m.Column + m.Columns.Count - 1)))
    for shape in ws.Shapes:
        try:
            printable = shape.DrawingObject.PrintObject
        except Exception:
            printable = True  # Include unknown object types rather than crop them.
        if shape.Visible and printable:
            a, b = shape.TopLeftCell, shape.BottomRightCell
            bounds.append((int(a.Row), int(a.Column), int(b.Row), int(b.Column)))
    if not bounds:
        return None
    return ws.Range(cells(min(b[0] for b in bounds), min(b[1] for b in bounds)),
                    cells(max(b[2] for b in bounds), max(b[3] for b in bounds)))

def values_flat(value):
    if isinstance(value, (tuple, list)):
        for v in value:
            yield from values_flat(v)
    else:
        yield value

def blank_candidate(ws, rule):
    ranges = rule.get("entry_ranges", [])
    if ranges:
        for address in ranges:
            r = ws.Range(address)
            if int(r.CountLarge) > 20000:
                raise ValueError("未記入判定範囲は2万セル以内にしてください")
            if any(v is not None and str(v).strip() != "" for v in values_flat(r.Value2)):
                return False
        return True
    if rule.get("area"):
        r = ws.Range(rule["area"])
        if int(r.CountLarge) > 20000 or ws.Shapes.Count:
            return False
        return not any(v is not None and str(v).strip() != "" for v in values_flat(r.Value2))
    return actual_range(ws) is None

def inspect_file(path, profile, overrides):
    # Even inspection uses a copy: no save or page-setting changes to the original.
    with tempfile.TemporaryDirectory(prefix="excel_review_") as temp:
        copied = Path(temp) / Path(path).name
        shutil.copy2(path, copied)
        with excel() as app, opened(app, copied) as book:
            rules = sheet_rules(profile, overrides)
            names = {ws.Name for ws in book.Worksheets}
            if set(rules) - names:
                raise ValueError(f"設定に存在しないシートがあります: {set(rules) - names}")
            result = []
            for ws in book.Worksheets:
                rule = rules.get(ws.Name, {})
                try:
                    blank = blank_candidate(ws, rule)
                except ValueError:
                    blank = None  # Range too large: allow user to set an explicit area.
                result.append({"name": ws.Name, "include": rule.get("include", ws.Visible == -1),
                               "area": rule.get("area", ""), "blank": blank,
                               "hidden": ws.Visible != -1})
            return result

def prepare(book, rules, part_dir, prefix, warnings, layout="a4"):
    if layout not in ("a4", "existing"):
        raise ValueError("印刷設定が不正です")
    names = {ws.Name for ws in book.Worksheets}
    if set(rules) - names:
        raise ValueError(f"{book.Name}: 設定に存在しないシートがあります: {set(rules) - names}")
    parts, sheet_names = [], []
    for ws in book.Worksheets:
        rule = rules.get(ws.Name, {})
        label = f"{book.Name} / {ws.Name}"
        if not rule.get("include", ws.Visible == -1):
            continue
        try:
            if blank_candidate(ws, rule):
                warnings.append(f"未記入候補（除外はしていません）: {label}")
        except ValueError:
            warnings.append(f"範囲が大きいため未記入判定を省略: {label}")
        explicit = rule.get("area")
        if layout == "existing":
            existing_area = ws.PageSetup.PrintArea
            rng = ws.Range(explicit or existing_area) if explicit or existing_area else ws.UsedRange
        else:
            rng = ws.Range(explicit) if explicit else actual_range(ws)
        if rng is None:
            raise ValueError(f"{label}: 完全な空白シートです。GUIで除外してください")
        if ws.ProtectContents and (layout == "a4" or explicit):
            raise ValueError(f"{label}: 保護されています。解除したコピーを入力にしてください")
        if ws.Visible != -1:
            ws.Visible = -1
        if layout == "a4" or explicit:
            ws.PageSetup.PrintArea = rng.Address
        if layout == "a4":
            ws.PageSetup.PaperSize = 9  # xlPaperA4
            ws.PageSetup.Orientation = 1  # xlPortrait
            ws.PageSetup.Zoom = False
            ws.PageSetup.FitToPagesWide = 1
            ws.PageSetup.FitToPagesTall = 1
            ws.PageSetup.PrintTitleRows = ""
            ws.PageSetup.PrintTitleColumns = ""
        if explicit:
            warnings.append(f"指定範囲の外に必要な内容がないか確認: {label} / {explicit}")
        if layout == "a4":
            ps = ws.PageSetup
            available_w = 595.28 - ps.LeftMargin - ps.RightMargin
            available_h = 841.89 - ps.TopMargin - ps.BottomMargin
            scale = min(1, available_w / max(float(rng.Width), 1), available_h / max(float(rng.Height), 1))
            if scale < .65:
                warnings.append(f"縮小率の目安 {scale:.0%}（読みにくさを確認）: {label}")
        if int(rng.CountLarge) <= 20000:
            hits = 0
            for c in rng:
                text = str(c.Text or "")
                if text.startswith(("#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#N/A", "#NUM!", "#SPILL!")) or (text and set(text) == {"#"}):
                    warnings.append(f"表示・数式エラー候補: {label}!{c.Address}: {text}")
                    hits += 1
                if hits >= 30:
                    warnings.append(f"表示エラー候補は30件で省略: {label}")
                    break
        else:
            warnings.append(f"セル数が多いため表示エラー走査を省略: {label}")
        part = part_dir / f"{prefix}_{len(parts):03d}.pdf"
        ws.ExportAsFixedFormat(Type=0, Filename=str(part), Quality=0,
                               IncludeDocProperties=False, IgnorePrintAreas=False,
                               OpenAfterPublish=False)
        parts.append(part); sheet_names.append(ws.Name)
    if not parts:
        raise ValueError(f"{book.Name}: 出力対象シートがありません")
    book.Save()
    return parts, sheet_names

def merge_pdf(parts, destination, enforce_a4=True):
    from pypdf import PdfReader, PdfWriter
    writer = PdfWriter()
    for part in parts:
        reader = PdfReader(str(part))
        if not reader.pages:
            raise ValueError(f"PDFが空です: {part.name}")
        if enforce_a4 and len(reader.pages) != 1:
            raise ValueError(f"1シート1ページになっていません: {part.name} ({len(reader.pages)}ページ)")
        for page in reader.pages:
            w, h = float(page.mediabox.width), float(page.mediabox.height)
            if enforce_a4 and (abs(w - 595.28) > 4 or abs(h - 841.89) > 4):
                raise ValueError(f"A4縦になっていません: {part.name}")
            writer.add_page(page)
    with open(destination, "wb") as f:
        writer.write(f)
    count = len(writer.pages)
    writer.close()
    return count

def build(config, job_name, output_root, progress=lambda s: None):
    job = validate(config, job_name)
    profiles = config["profiles"]
    output_root = Path(output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=".building_", dir=output_root))
    try:
        copies, parts_dir = stage / "Excel出力用", stage / "ページ"
        copies.mkdir(); parts_dir.mkdir()
        documents = ordered_documents(job)
        inputs = [{"file": job["cover_file"]}, *documents]
        snapshots, originals = [], []
        for i, d in enumerate(inputs):
            p = source(job["folder"], d["file"])
            before = digest(p)
            copied = copies / f"{i:03d}_{p.name}"
            shutil.copy2(p, copied)
            if digest(p) != before or digest(copied) != before:
                raise ValueError(f"処理中に元ファイルが変更されました: {p.name}")
            snapshots.append(copied)
            originals.append({"file": str(p), "sha256": before})
        records, warnings, doc_parts, print_plan = [], [], [], []
        with excel() as app:
            for i, d in enumerate(documents, 1):
                progress(f"読み取り・PDF化: {d['file']}")
                profile = profiles[d["profile"]]
                with opened(app, snapshots[i]) as book:
                    record = {"system": d["system"], "file": d["file"], "role": d["role"]}
                    for kind in ("work", "check"):
                        try:
                            record[kind] = parse_date(value_at(book, profile["date_sheet"], profile[kind + "_cell"]), bool(book.Date1904))
                        except Exception as e:
                            raise ValueError(f"{d['file']} / {kind}: {e}") from e
                    records.append(record)
                    parts, sheets = prepare(book, sheet_rules(profile, d.get("sheets", {})), parts_dir, f"{i:03d}", warnings)
                    doc_parts.extend(parts)
                    print_plan.append({"file": str(snapshots[i].relative_to(stage)), "sheets": sheets})
            dates = aggregate(records)
            progress("全体表紙へ最早日を転記")
            with opened(app, snapshots[0]) as cover:
                ws = cover.Worksheets(job["cover_sheet"])
                merged_targets = set()
                for s in ordered_systems(job):
                    label = str(value_at(cover, job["cover_sheet"], s["name_cell"]) or "").strip()
                    if label != s["name"]:
                        raise ValueError(f"表紙の名称が設定と一致しません: {s['name_cell']} 設定={s['name']} 実際={label}")
                    for key in ("name_cell", "work_cell", "check_cell"):
                        address = ws.Range(s[key]).MergeArea.Cells(1, 1).Address
                        if address in merged_targets:
                            raise ValueError(f"結合セルの転記先が重複しています: {address}")
                        merged_targets.add(address)
                for s in ordered_systems(job):
                    for kind in ("work", "check"):
                        target = ws.Range(s[kind + "_cell"]).MergeArea.Cells(1, 1)
                        target.Value2 = serial(dates[s["id"]][kind], bool(cover.Date1904))
                        target.NumberFormat = "yyyy/mm/dd"
                cover_parts, sheets = prepare(cover, profiles[job["cover_profile"]]["sheets"], parts_dir, "000", warnings)
                if job["cover_sheet"] not in sheets:
                    raise ValueError("転記先の表紙シートが出力から除外されています")
                print_plan.insert(0, {"file": str(snapshots[0].relative_to(stage)), "sheets": sheets})
        pdf_name = job_name + ".pdf"
        pages = merge_pdf(cover_parts + doc_parts, stage / pdf_name)
        for p in print_plan:
            p["sha256"] = digest(stage / p["file"])
        audit = {"job": job_name, "pdf": pdf_name, "pdf_sha256": digest(stage / pdf_name),
                 "pages": pages, "source_files": originals, "print_plan": print_plan,
                 "dates": [{**r, "work": r["work"].isoformat(), "check": r["check"].isoformat()} for r in records],
                 "selected_dates": {k: {x: y.isoformat() for x, y in v.items()} for k, v in dates.items()},
                 "warnings": warnings}
        write_json(stage / "処理記録.json", audit)
        write_json(stage / "使用設定.json", config)
        (stage / "確認事項.txt").write_text("\n".join([
            f"{job_name}: {pages}ページ", "誤字・文字切れの完全判定は行いません。PDFを目視確認してください。",
            "入力Excelの外部リンク更新は無効です。元Excelの計算・保存状態も確認してください。", *warnings]), encoding="utf-8-sig")
        final = output_root / (job_name + "_" + dt.datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6])
        stage.rename(final)
        return str(final)
    except Exception:
        if stage.parent.resolve() == output_root and stage.name.startswith(".building_"):
            shutil.rmtree(stage, ignore_errors=True)
        raise

def print_result(folder, progress=lambda s: None):
    """Printer setup dialog occurs before any printing; originals are never used."""
    folder = Path(folder).resolve()
    audit = read_json(folder / "処理記録.json")
    for item in audit["print_plan"]:
        path = (folder / item["file"]).resolve()
        if not path.is_relative_to(folder) or digest(path) != item["sha256"]:
            raise ValueError("出力用Excelが変更されています。PDFを作り直してください")
    pdfs = audit.get("pdfs")
    if pdfs is None:
        pdfs = [{"file": audit["pdf"], "sha256": audit["pdf_sha256"]}]
    for item in pdfs:
        path = (folder / item["file"]).resolve()
        if not path.is_relative_to(folder) or digest(path) != item["sha256"]:
            raise ValueError("PDFが変更されています。作り直してください")
    with excel() as app:
        app.Visible = True
        # xlDialogPrinterSetup = 9; False means cancellation.
        if not app.Dialogs(9).Show():
            return "印刷をキャンセルしました"
        for item in audit["print_plan"]:
            with opened(app, folder / item["file"]) as book:
                for name in item["sheets"]:
                    progress(f"プリンターへ送信: {Path(item['file']).name} / {name}")
                    book.Worksheets(name).PrintOut(Copies=1, IgnorePrintAreas=False)
    return "プリンターへ送信しました。用紙の出力を確認してください。"

def build_general(plan, output_root, progress=lambda s: None):
    """Export arbitrary Excel files in list order without date or cover processing."""
    validate_general(plan)
    output_root = Path(output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=".building_", dir=output_root))
    try:
        copies, parts_dir = stage / "Excel出力用", stage / "ページ"
        copies.mkdir(); parts_dir.mkdir()
        snapshots, originals = [], []
        for i, doc in enumerate(plan["documents"], 1):
            src = Path(doc["file"]).resolve()
            before = digest(src)
            copied = copies / f"{i:03d}_{src.name}"
            shutil.copy2(src, copied)
            if digest(src) != before or digest(copied) != before:
                raise ValueError(f"処理中に元ファイルが変更されました: {src.name}")
            snapshots.append(copied)
            originals.append({"file": str(src), "sha256": before})
        warnings, all_parts, print_plan, pdfs = [], [], [], []
        strict = plan["layout"] == "a4"
        with excel() as app:
            for i, (doc, copied) in enumerate(zip(plan["documents"], snapshots), 1):
                progress(f"一般Excel出力: {Path(doc['file']).name}")
                with opened(app, copied) as book:
                    parts, sheets = prepare(book, doc.get("sheets", {}), parts_dir, f"{i:03d}", warnings, layout=plan["layout"])
                all_parts.extend(parts)
                print_plan.append({"file": str(copied.relative_to(stage)), "sheets": sheets, "sha256": digest(copied)})
                if plan["output"] == "individual":
                    name = f"{i:03d}_{Path(doc['file']).stem}.pdf"
                    count = merge_pdf(parts, stage / name, enforce_a4=strict)
                    pdfs.append({"file": name, "pages": count, "sha256": digest(stage / name)})
        if plan["output"] == "combined":
            name = "一括.pdf"
            count = merge_pdf(all_parts, stage / name, enforce_a4=strict)
            pdfs.append({"file": name, "pages": count, "sha256": digest(stage / name)})
        audit = {"job": "一般Excel出力", "pdfs": pdfs, "pages": sum(p["pages"] for p in pdfs),
                 "source_files": originals, "print_plan": print_plan, "warnings": warnings}
        write_json(stage / "処理記録.json", audit)
        write_json(stage / "使用設定.json", plan)
        (stage / "確認事項.txt").write_text("\n".join([
            f"一般Excel出力: {audit['pages']}ページ / {len(pdfs)}ファイル",
            "日付転記は行っていません。誤字・文字切れはPDFで目視確認してください。",
            "既存の印刷設定を使用" if not strict else "A4縦・1シート1ページへ変更",
            "明示した印刷範囲は既存設定より優先されます。外部リンクの更新は無効です。", *warnings]), encoding="utf-8-sig")
        final = output_root / ("一般Excel出力_" + dt.datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6])
        stage.rename(final)
        return str(final)
    except Exception:
        if stage.parent.resolve() == output_root and stage.name.startswith(".building_"):
            shutil.rmtree(stage, ignore_errors=True)
        raise
