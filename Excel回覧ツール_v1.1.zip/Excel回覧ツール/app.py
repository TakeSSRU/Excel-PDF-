from __future__ import annotations
import copy
import datetime as dt
import os
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import traceback
from core import read_json, write_json, validate, validate_sheets, source, parse_config_text
import excel_engine

BASE = Path(__file__).resolve().parent

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Excel回覧ツール 1.1 — 一般出力・移行申請・完了報告")
        self.geometry("1150x740")
        self.minsize(900, 620)
        self.config_path = BASE / "settings" / "project.json"
        self.config_data = read_json(self.config_path)
        self.events = queue.Queue()
        self.busy = False
        self.results = {}
        self.general_window = None
        self.current_job = tk.StringVar(value="移行申請")
        self.folder = tk.StringVar()
        self.cover = tk.StringVar()
        self.status = tk.StringVar(value="初回は社内AIが settings/project.json の帳票・表紙設定を作成してください。")
        bar = ttk.Frame(self, padding=10); bar.pack(fill="x")
        ttk.Label(bar, text="書類区分").pack(side="left")
        self.job_combo = ttk.Combobox(bar, textvariable=self.current_job, values=["移行申請", "完了報告"], state="readonly", width=12)
        self.job_combo.pack(side="left", padx=8)
        self.job_combo.bind("<<ComboboxSelected>>", self.change_job)
        ttk.Button(bar, text="設定を読み込み", command=self.load).pack(side="left", padx=4)
        ttk.Button(bar, text="設定を保存", command=self.save).pack(side="left", padx=4)
        ttk.Button(bar, text="GeminiのJSONを貼り付け", command=self.paste_json).pack(side="left", padx=4)
        ttk.Button(bar, text="一般ExcelのPDF化・印刷", command=self.open_general).pack(side="left", padx=4)
        ttk.Button(bar, text="引継ぎ書", command=lambda: os.startfile(str(BASE / "社内AIへの引継ぎ書.md"))).pack(side="right")
        paths = ttk.Frame(self, padding=(10, 0)); paths.pack(fill="x")
        paths.columnconfigure(1, weight=1)
        ttk.Label(paths, text="対象フォルダ").grid(row=0, column=0, sticky="w", pady=5)
        ttk.Entry(paths, textvariable=self.folder, state="readonly").grid(row=0, column=1, sticky="ew")
        ttk.Button(paths, text="選択", command=self.choose_folder).grid(row=0, column=2, padx=5)
        ttk.Label(paths, text="全体表紙").grid(row=1, column=0, sticky="w", pady=5)
        ttk.Entry(paths, textvariable=self.cover, state="readonly").grid(row=1, column=1, sticky="ew")
        ttk.Button(paths, text="選択", command=self.choose_cover).grid(row=1, column=2, padx=5)
        controls = ttk.Frame(self, padding=10); controls.pack(fill="x")
        for label, command in [("Excelを追加・対応づけ", self.add_document), ("選択行を編集", self.edit_document),
                               ("選択行を削除", self.remove_document), ("シート選択・範囲", self.inspect_selected),
                               ("表紙のシート選択", self.inspect_cover)]:
            ttk.Button(controls, text=label, command=command).pack(side="left", padx=3)
        ttk.Label(self, text="出力順：表紙 → 表紙の上からシステム順 → 開発 → 運用（同じ区分内は登録順）", padding=(12, 0)).pack(anchor="w")
        table = ttk.Frame(self)
        table.pack(fill="both", expand=True, padx=10, pady=8)
        self.tree = ttk.Treeview(table, columns=("file", "system", "role", "profile"), show="headings", height=12, selectmode="browse")
        for key, title, width in [("file", "Excelファイル", 450), ("system", "システム", 180), ("role", "区分", 80), ("profile", "帳票設定", 170)]:
            self.tree.heading(key, text=title); self.tree.column(key, width=width)
        scrollbar = ttk.Scrollbar(table, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        actions = ttk.Frame(self, padding=10); actions.pack(fill="x")
        for title, action in [("設定チェック", self.check), ("PDF作成・表紙転記", self.build),
                              ("PDFを開く（確認・印刷）", self.open_pdf), ("Excelから印刷…", self.print_excel),
                              ("出力フォルダ", self.open_output)]:
            ttk.Button(actions, text=title, command=action).pack(side="left", padx=3)
        ttk.Label(self, text="元Excelは変更しません。出力用コピーへ転記します。印刷前にPDFと確認事項.txtをご確認ください。", padding=(12, 0)).pack(anchor="w")
        ttk.Label(self, textvariable=self.status, wraplength=1100, padding=12).pack(fill="x")
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()
        self.after(150, self.poll)

    def available(self):
        if self.busy:
            messagebox.showinfo("処理中", "処理完了までお待ちください。Excelのダイアログが開いていないかも確認してください。")
            return False
        return True

    def job(self):
        return self.config_data["jobs"][self.current_job.get()]

    def refresh(self):
        self.folder.set(self.job()["folder"]); self.cover.set(self.job()["cover_file"])
        self.tree.delete(*self.tree.get_children())
        names = {s["id"]: s["name"] for s in self.job()["systems"]}
        for i, d in enumerate(self.job()["documents"]):
            self.tree.insert("", "end", iid=str(i), values=(d["file"], names.get(d["system"], d["system"]), d["role"], d["profile"]))

    def change_job(self, _event=None):
        self.refresh()

    def save(self):
        if self.available():
            write_json(self.config_path, self.config_data)
            self.status.set(f"設定を保存しました: {self.config_path}")

    def load(self):
        if not self.available(): return
        path = filedialog.askopenfilename(initialdir=BASE / "settings", filetypes=[("JSON設定", "*.json")])
        if not path: return
        try:
            config = parse_config_text(Path(path).read_text(encoding="utf-8-sig"))
            self.config_data = config; self.config_path = Path(path)
            self.results.clear(); self.refresh()
            self.status.set("設定を読み込みました。「設定チェック」で確認してください。")
        except Exception as e:
            messagebox.showerror("設定エラー", str(e))

    def open_general(self):
        if not self.available(): return
        if self.general_window is not None and self.general_window.winfo_exists():
            self.general_window.lift(); return
        from general import GeneralWindow
        self.general_window = GeneralWindow(self)

    def paste_json(self):
        if not self.available(): return
        from tkinter.scrolledtext import ScrolledText
        dialog = tk.Toplevel(self); dialog.title("Geminiが出力した設定JSONを貼り付け"); dialog.geometry("850x600")
        dialog.transient(self); dialog.grab_set()
        ttk.Label(dialog, text="JSON全文を貼り付けてください。```json の囲み付きでも取り込めます。\n取り込むと標準の settings/project.json に保存します。従来の設定はバックアップします。", padding=12).pack(fill="x")
        editor = ScrolledText(dialog, wrap="none"); editor.pack(fill="both", expand=True, padx=10)
        def accept():
            try:
                config = parse_config_text(editor.get("1.0", "end"))
                target = BASE / "settings" / "project.json"
                if target.exists():
                    backup = target.with_name("project.before_import_" + dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".json")
                    backup.write_bytes(target.read_bytes())
                write_json(target, config)
                self.config_data = config; self.config_path = target; self.results.clear()
                self.refresh(); dialog.destroy()
                self.status.set("設定JSONを取り込んで保存しました。対象フォルダとファイルを選び、設定チェックを実行してください。")
            except Exception as e:
                messagebox.showerror("取り込みエラー", str(e), parent=dialog)
        ttk.Button(dialog, text="取り込んで保存", command=accept).pack(pady=10)

    def choose_folder(self):
        if not self.available(): return
        path = filedialog.askdirectory()
        if path:
            self.job()["folder"] = path; self.refresh()

    def select_file(self):
        folder = Path(self.job()["folder"])
        if not folder.is_dir():
            raise ValueError("先に対象フォルダを選択してください")
        filename = filedialog.askopenfilename(initialdir=folder, filetypes=[("Excel", "*.xlsx *.xlsm *.xls *.xlsb")])
        if not filename: return None
        path = Path(filename).resolve()
        if not path.is_relative_to(folder.resolve()):
            raise ValueError("選択した対象フォルダ内のExcelを指定してください")
        return str(path.relative_to(folder.resolve()))

    def choose_cover(self):
        if not self.available(): return
        try:
            path = self.select_file()
            if path: self.job()["cover_file"] = path; self.refresh()
        except Exception as e: messagebox.showerror("選択エラー", str(e))

    def selected(self):
        rows = self.tree.selection()
        return int(rows[0]) if rows else None

    def add_document(self):
        if not self.available(): return
        try:
            path = self.select_file()
            if path: self.document_dialog({"file": path, "system": "", "role": "開発", "profile": ""}, None)
        except Exception as e: messagebox.showerror("選択エラー", str(e))

    def edit_document(self):
        if not self.available(): return
        i = self.selected()
        if i is not None: self.document_dialog(copy.deepcopy(self.job()["documents"][i]), i)

    def document_dialog(self, doc, index):
        names = {s["name"]: s["id"] for s in self.job()["systems"]}
        profiles = [k for k, p in self.config_data["profiles"].items() if p.get("date_sheet")]
        if not names or not profiles:
            messagebox.showinfo("初期設定が必要", "社内AIに settings/project.json のシステム一覧と日付セルを設定してもらってください。")
            return
        dialog = tk.Toplevel(self); dialog.title("Excelの対応づけ"); dialog.transient(self); dialog.grab_set()
        ttk.Label(dialog, text=doc["file"], padding=12).grid(row=0, columnspan=2)
        variables = []
        for row, (label, values, initial) in enumerate([
            ("システム", list(names), next((n for n, sid in names.items() if sid == doc["system"]), "")),
            ("区分", ["開発", "運用"], doc["role"]), ("帳票設定", profiles, doc["profile"])], 1):
            ttk.Label(dialog, text=label, padding=10).grid(row=row, column=0)
            v = tk.StringVar(value=initial); variables.append(v)
            ttk.Combobox(dialog, values=values, textvariable=v, state="readonly", width=35).grid(row=row, column=1, padx=10)
        def accept():
            name, role, profile = [v.get() for v in variables]
            if name not in names or profile not in profiles:
                messagebox.showerror("未選択", "システムと帳票設定を選択してください", parent=dialog); return
            if profile != doc["profile"]: doc.pop("sheets", None)
            doc.update(system=names[name], role=role, profile=profile)
            if index is None: self.job()["documents"].append(doc)
            else: self.job()["documents"][index] = doc
            self.refresh(); dialog.destroy()
        ttk.Button(dialog, text="登録", command=accept).grid(row=4, columnspan=2, pady=15)

    def remove_document(self):
        if not self.available(): return
        i = self.selected()
        if i is not None:
            del self.job()["documents"][i]; self.refresh()

    def inspect_selected(self):
        if not self.available(): return
        i = self.selected()
        if i is None: return
        d = self.job()["documents"][i]
        self.inspect(d["file"], self.config_data["profiles"][d["profile"]], d.get("sheets", {}),
                     lambda rules: d.update(sheets=rules))

    def inspect_cover(self):
        if not self.available(): return
        p = self.config_data["profiles"][self.job()["cover_profile"]]
        self.inspect(self.job()["cover_file"], p, {}, lambda rules: p.update(sheets=rules))

    def inspect(self, filename, profile, overrides, setter):
        try:
            path = source(self.job()["folder"], filename)
            self.run(lambda progress: excel_engine.inspect_file(path, profile, overrides),
                     lambda rows: self.sheet_dialog(rows, setter, profile, overrides))
        except Exception as e: messagebox.showerror("検査エラー", str(e))

    def sheet_dialog(self, rows, setter, profile, overrides, general=False):
        from core import sheet_rules
        previous = sheet_rules(profile, overrides)
        dialog = tk.Toplevel(self); dialog.title("出力シート・印刷範囲"); dialog.geometry("770x530"); dialog.transient(self); dialog.grab_set()
        hint = "空欄：既存設定モードでは元の範囲、A4モードでは内容から推定。" if general else "空欄は内容・図形から推定。"
        ttk.Label(dialog, text="チェックあり＝出力。範囲は A1:L45 形式。" + hint + "\n未記入候補も自動では除外しません。目視で判断してください。", padding=10).pack(fill="x")
        canvas = tk.Canvas(dialog); scroll = ttk.Scrollbar(dialog, orient="vertical", command=canvas.yview)
        scroll.pack(side="right", fill="y"); canvas.pack(fill="both", expand=True)
        canvas.configure(yscrollcommand=scroll.set)
        frame = ttk.Frame(canvas); canvas.create_window((0, 0), window=frame, anchor="nw")
        frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        values = []
        for i, r in enumerate(rows):
            include, area = tk.BooleanVar(value=r["include"]), tk.StringVar(value=r["area"])
            values.append((r["name"], include, area))
            ttk.Checkbutton(frame, text=r["name"], variable=include, width=28).grid(row=i, column=0, padx=8, pady=5)
            ttk.Entry(frame, textvariable=area, width=20).grid(row=i, column=1)
            flags = ("未記入判定は省略 " if r["blank"] is None else "未記入候補 " if r["blank"] else "") + ("非表示シート" if r["hidden"] else "")
            ttk.Label(frame, text=flags).grid(row=i, column=2, padx=10)
        def accept():
            try:
                rules = {name: {**previous.get(name, {}), "include": inc.get(), "area": area.get().strip()}
                         for name, inc, area in values}
                validate_sheets(rules, "シート選択")
                setter(rules); dialog.destroy()
            except Exception as e: messagebox.showerror("範囲エラー", str(e), parent=dialog)
        ttk.Button(dialog, text="設定に反映", command=accept).pack(pady=10)

    def check(self):
        if not self.available(): return
        try:
            validate(self.config_data, self.current_job.get())
            messagebox.showinfo("設定チェック", "設定とファイルの存在を確認しました。\nセルの実値・シート名はPDF作成時に検証します。")
        except Exception as e: messagebox.showerror("設定チェック", str(e))

    def build(self):
        if not self.available(): return
        folder = filedialog.askdirectory(title="PDF・転記済み表紙の保存先")
        if not folder: return
        self.save()
        name = self.current_job.get(); config = copy.deepcopy(self.config_data)
        def done(path):
            self.results[name] = path
            self.status.set(f"完成: {path}")
            messagebox.showinfo("PDF作成完了", "PDF・転記済みExcel・処理記録を保存しました。\nPDFと確認事項.txtを確認してから印刷してください。")
        self.run(lambda progress: excel_engine.build(config, name, folder, progress), done)

    def result(self):
        path = self.results.get(self.current_job.get())
        if not path: messagebox.showinfo("PDF未作成", "この起動中に「PDF作成・表紙転記」を実行してください。")
        return path

    def open_pdf(self):
        if not self.available(): return
        path = self.result()
        if path:
            os.startfile(str(Path(path) / (self.current_job.get() + ".pdf")))
            self.status.set("PDFビューアーで確認し、Ctrl+Pで一括印刷できます。保存済みPDFと同じページを印刷する方法です。")

    def open_output(self):
        if not self.available(): return
        path = self.result()
        if path: os.startfile(path)

    def print_excel(self):
        if not self.available(): return
        path = self.result()
        if path and messagebox.askyesno("Excelから印刷", "最後に作成した出力用Excelを1部印刷します。設定変更後は先にPDFを作り直してください。\n\nプリンター設定でOKを押すと印刷を開始します。シートごとに別ジョブになります。途中で失敗した場合、印刷済み用紙を確認し、PDFから残りのページを印刷してください。\n\nPDFと同じページを一括印刷するには「PDFを開く」を使用してください。続けますか？"):
            self.run(lambda progress: excel_engine.print_result(path, progress), lambda result: self.status.set(result))

    def run(self, operation, done):
        self.busy = True; self.job_combo.configure(state="disabled")
        self.status.set("処理中です。Excelのダイアログが表示された場合は内容を確認してください。")
        def worker():
            try:
                result = operation(lambda s: self.events.put(("progress", s)))
                self.events.put(("done", (done, result)))
            except Exception:
                self.events.put(("error", traceback.format_exc()))
        threading.Thread(target=worker, daemon=True).start()

    def poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "progress": self.status.set(value)
                else:
                    self.busy = False; self.job_combo.configure(state="readonly")
                    if kind == "done":
                        callback, result = value; callback(result)
                    else:
                        log = BASE / "logs" / "last_error.txt"; log.parent.mkdir(exist_ok=True)
                        log.write_text(value, encoding="utf-8-sig")
                        self.status.set("処理に失敗しました。元Excelは変更していません。")
                        messagebox.showerror("処理エラー", value.splitlines()[-1] + f"\n\n詳細: {log}")
        except queue.Empty:
            pass
        self.after(150, self.poll)

    def close(self):
        if not self.available(): return
        if self.general_window is not None and self.general_window.winfo_exists():
            self.general_window.close()
            if self.general_window.winfo_exists(): return
        self.destroy()

def main():
    App().mainloop()

if __name__ == "__main__":
    raise SystemExit("起動.cmd から起動してください（本体整合性チェック必須）")
