"""General Excel export GUI. No migration-specific configuration required."""
import copy
import os
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from core import read_json, write_json, validate_general
import excel_engine

class GeneralWindow(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.title("一般のExcelをPDF化・印刷")
        self.geometry("980x650")
        self.minsize(820, 560)
        self.path = Path(__file__).resolve().parent / "settings" / "general.json"
        self.plan = {"version": 1, "layout": "existing", "output": "combined", "documents": []}
        if self.path.exists():
            try:
                saved = read_json(self.path)
                if saved.get("documents"):
                    validate_general(saved, check_files=False)
                    self.plan = saved
            except Exception as e:
                messagebox.showwarning("一般設定", f"保存済み設定を読み込めません。新規一覧で開きます。\n{e}", parent=self)
        self.result_folder = None
        self.layout = tk.StringVar(value=self.plan["layout"])
        self.output = tk.StringVar(value=self.plan["output"])
        ttk.Label(self, text="日付転記・システム登録なしで使えます。上からファイル順、各ファイル内は元のシート順です。", padding=12).pack(anchor="w")
        buttons = ttk.Frame(self, padding=(10, 0)); buttons.pack(fill="x")
        for title, action in [("Excelを追加（複数選択可）", self.add), ("削除", self.remove),
                              ("↑ 上へ", lambda: self.move(-1)), ("↓ 下へ", lambda: self.move(1)),
                              ("対象シート・範囲", self.inspect), ("一覧・設定を保存", self.save)]:
            ttk.Button(buttons, text=title, command=action).pack(side="left", padx=3)
        table = ttk.Frame(self, padding=10); table.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(table, columns=("order", "file", "sheets"), show="headings", selectmode="browse")
        for key, title, width in [("order", "順", 45), ("file", "Excelファイル（保存先が違っても追加できます）", 640), ("sheets", "シート設定", 140)]:
            self.tree.heading(key, text=title); self.tree.column(key, width=width)
        scroll = ttk.Scrollbar(table, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y"); self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(fill="both", expand=True)
        options = ttk.LabelFrame(self, text="出力方法", padding=10); options.pack(fill="x", padx=10)
        ttk.Radiobutton(options, text="既存の印刷設定を使う（用紙・向き・改ページを維持）", variable=self.layout, value="existing").grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(options, text="A4縦・1シート1ページ", variable=self.layout, value="a4").grid(row=0, column=1, sticky="w", padx=15)
        ttk.Radiobutton(options, text="すべてを1つのPDFに結合", variable=self.output, value="combined").grid(row=1, column=0, sticky="w", pady=8)
        ttk.Radiobutton(options, text="Excelファイルごとに別PDF", variable=self.output, value="individual").grid(row=1, column=1, sticky="w", padx=15)
        ttk.Label(self, text="印刷範囲を明示すると既存の範囲より優先します。表示シートは既定で対象、非表示シートは対象外です。", padding=10).pack(anchor="w")
        actions = ttk.Frame(self, padding=10); actions.pack(fill="x")
        for title, action in [("PDFを作成", self.build), ("PDFを開く（確認・印刷）", self.open_pdf),
                              ("Excelから印刷…", self.print_excel), ("出力フォルダ", self.open_folder)]:
            ttk.Button(actions, text=title, command=action).pack(side="left", padx=3)
        # Use the same progress state and Excel worker as the main window.
        ttk.Label(self, textvariable=app.status, wraplength=920, padding=12).pack(fill="x")
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()

    def refresh(self, selection=None):
        self.tree.delete(*self.tree.get_children())
        for i, d in enumerate(self.plan["documents"]):
            self.tree.insert("", "end", iid=str(i), values=(i + 1, d["file"], "個別指定あり" if d.get("sheets") else "表示シートすべて"))
        if selection is not None and self.tree.exists(str(selection)):
            self.tree.selection_set(str(selection)); self.tree.see(str(selection))

    def selected(self):
        selected = self.tree.selection()
        return int(selected[0]) if selected else None

    def add(self):
        if not self.app.available(): return
        paths = filedialog.askopenfilenames(parent=self, title="PDF化するExcelを選択", filetypes=[("Excel", "*.xlsx *.xlsm *.xls *.xlsb")])
        existing = {Path(d["file"]).resolve() for d in self.plan["documents"]}
        for path in paths:
            p = Path(path).resolve()
            if p not in existing and not p.name.startswith("~$"):
                self.plan["documents"].append({"file": str(p), "sheets": {}}); existing.add(p)
        self.refresh()

    def remove(self):
        if not self.app.available(): return
        index = self.selected()
        if index is not None:
            del self.plan["documents"][index]; self.refresh()

    def move(self, delta):
        if not self.app.available(): return
        i = self.selected()
        if i is not None and 0 <= i + delta < len(self.plan["documents"]):
            docs = self.plan["documents"]; docs[i], docs[i + delta] = docs[i + delta], docs[i]
            self.refresh(i + delta)

    def inspect(self):
        if not self.app.available(): return
        index = self.selected()
        if index is None: return
        doc = self.plan["documents"][index]
        def setter(rules):
            doc["sheets"] = rules; self.refresh(index)
        self.app.run(lambda progress: excel_engine.inspect_file(doc["file"], {"sheets": {}}, doc.get("sheets", {})),
                     lambda rows: self.app.sheet_dialog(rows, setter, {"sheets": {}}, doc.get("sheets", {}), general=True))

    def snapshot(self):
        plan = copy.deepcopy(self.plan)
        plan.update(layout=self.layout.get(), output=self.output.get())
        return plan

    def save(self):
        if not self.app.available(): return
        try:
            write_json(self.path, self.snapshot())
            self.app.status.set("一般出力の一覧・順序・シート設定を保存しました。")
        except Exception as e: messagebox.showerror("保存エラー", str(e), parent=self)

    def build(self):
        if not self.app.available(): return
        try:
            plan = self.snapshot(); validate_general(plan)
            destination = filedialog.askdirectory(parent=self, title="PDFの保存先")
            if not destination: return
            write_json(self.path, plan)
        except Exception as e:
            messagebox.showerror("設定エラー", str(e), parent=self); return
        def done(folder):
            self.result_folder = folder
            self.app.status.set(f"一般PDFを作成しました: {folder}")
            messagebox.showinfo("完了", "PDFと確認事項.txtを確認してから印刷してください。\n元Excelは変更していません。", parent=self)
        self.app.run(lambda progress: excel_engine.build_general(plan, destination, progress), done)

    def result(self):
        if not self.result_folder:
            messagebox.showinfo("PDF未作成", "先に「PDFを作成」を実行してください。", parent=self)
        return self.result_folder

    def open_pdf(self):
        if not self.app.available(): return
        folder = self.result()
        if not folder: return
        audit = read_json(Path(folder) / "処理記録.json")
        pdfs = audit["pdfs"]
        if len(pdfs) == 1:
            os.startfile(str(Path(folder) / pdfs[0]["file"]))
        else:
            dialog = tk.Toplevel(self); dialog.title("開くPDFを選択"); dialog.geometry("560x350")
            choices = tk.Listbox(dialog)
            for p in pdfs: choices.insert("end", f"{p['file']}（{p['pages']}ページ）")
            choices.pack(fill="both", expand=True, padx=10, pady=10)
            def open_selected(_event=None):
                if choices.curselection():
                    os.startfile(str(Path(folder) / pdfs[choices.curselection()[0]]["file"]))
            choices.bind("<Double-1>", open_selected)
            ttk.Button(dialog, text="選択したPDFを開く", command=open_selected).pack(pady=8)
        self.app.status.set("PDFビューアーで確認後、Ctrl+Pで印刷できます。変更後はPDFを作り直してください。")

    def open_folder(self):
        if not self.app.available(): return
        folder = self.result()
        if folder: os.startfile(folder)

    def print_excel(self):
        if not self.app.available(): return
        folder = self.result()
        if folder and messagebox.askyesno("印刷の確認", "最後にPDFを作成したときのExcelコピーを1部印刷します。\n設定・ファイルを変えた場合は先にPDFを作り直してください。\n\nプリンター設定でOKを押すと印刷します。シート単位の別ジョブです。途中で失敗した場合はPDFから未印刷ページだけを印刷してください。続けますか？", parent=self):
            self.app.run(lambda progress: excel_engine.print_result(folder, progress), lambda text: self.app.status.set(text))

    def close(self):
        if self.app.available():
            # Save even an empty list so removed documents do not return next time.
            try:
                write_json(self.path, self.snapshot())
            except Exception as e:
                messagebox.showerror("保存エラー", str(e), parent=self); return
            self.destroy()
