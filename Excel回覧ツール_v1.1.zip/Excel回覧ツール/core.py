"""Frozen business rules. Company AI edits settings/project.json, never this file."""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import re

ROLES = {"開発": 0, "運用": 1}
EXTENSIONS = {".xlsx", ".xlsm", ".xls", ".xlsb"}

def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)

def keys(obj, allowed, required, where):
    if not isinstance(obj, dict):
        raise ValueError(f"{where}: オブジェクトが必要です")
    extra, missing = set(obj) - set(allowed), set(required) - set(obj)
    if extra or missing:
        raise ValueError(f"{where}: 未対応キー={sorted(extra)} / 不足キー={sorted(missing)}")

def cell(address):
    if not isinstance(address, str) or not re.fullmatch(r"[A-Z]{1,3}[1-9][0-9]{0,6}", address):
        raise ValueError(f"セルは A1 形式で指定してください: {address!r}")
    letters, row = re.fullmatch(r"([A-Z]+)([0-9]+)", address).groups()
    col = 0
    for c in letters:
        col = col * 26 + ord(c) - 64
    if col > 16384 or int(row) > 1048576:
        raise ValueError(f"Excelの範囲外: {address}")
    return int(row), col

def area(address):
    if not isinstance(address, str):
        raise ValueError("印刷範囲は文字列で指定してください")
    parts = address.split(":")
    if len(parts) not in (1, 2):
        raise ValueError(f"単一の矩形範囲を指定してください: {address}")
    first, last = cell(parts[0]), cell(parts[-1])
    if first[0] > last[0] or first[1] > last[1]:
        raise ValueError(f"範囲の向きが逆です: {address}")
    return first, last

def parse_date(value, date1904=False):
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if not math.isfinite(value) or value < (0 if date1904 else 1) or value > 2957000:
            raise ValueError(f"日付シリアル値が不正です: {value}")
        days = int(value)
        if not date1904 and days == 60:
            raise ValueError("実在しない1900年2月29日は使用できません")
        base = dt.date(1904, 1, 1) if date1904 else dt.date(1899, 12, 31)
        return base + dt.timedelta(days=days if date1904 or days < 60 else days - 1)
    s = str(value or "").strip()
    m = re.fullmatch(r"(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})日?", s)
    if m:
        return dt.date(*map(int, m.groups()))
    raise ValueError(f"日付を確定できません: {value!r}。年を含む日付に修正してください")

def serial(value, date1904=False):
    if date1904:
        return (value - dt.date(1904, 1, 1)).days
    return (value - dt.date(1899, 12, 31)).days + (value >= dt.date(1900, 3, 1))

def source(root, relative):
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise ValueError("ファイル名は対象フォルダ内の相対パスで指定してください")
    root = Path(root).resolve()
    p = (root / relative).resolve()
    if not p.is_relative_to(root) or p.suffix.lower() not in EXTENSIONS or p.name.startswith("~$"):
        raise ValueError(f"対象外のファイル: {relative}")
    if not p.is_file():
        raise ValueError(f"ファイルがありません: {p}")
    return p

def validate_sheets(sheets, where):
    if not isinstance(sheets, dict):
        raise ValueError(f"{where}: sheets はオブジェクトです")
    for name, rule in sheets.items():
        keys(rule, ["include", "area", "entry_ranges"], [], f"{where}/{name}")
        if "include" in rule and type(rule["include"]) is not bool:
            raise ValueError("include は true / false です")
        if rule.get("area"):
            area(rule["area"])
        if not isinstance(rule.get("entry_ranges", []), list):
            raise ValueError("entry_ranges は範囲文字列の配列です")
        for r in rule.get("entry_ranges", []):
            area(r)

def validate(config, job_name, check_files=True, allow_unassigned=False):
    keys(config, ["version", "profiles", "jobs"], ["version", "profiles", "jobs"], "設定")
    if config["version"] != 1:
        raise ValueError("設定versionは1のみ対応しています")
    if set(config["jobs"]) != {"移行申請", "完了報告"} or job_name not in {"移行申請", "完了報告"}:
        raise ValueError("書類区分は移行申請・完了報告の2種類です")
    profiles = config["profiles"]
    for name, p in profiles.items():
        keys(p, ["date_sheet", "work_cell", "check_cell", "sheets"], ["sheets"], f"帳票/{name}")
        validate_sheets(p["sheets"], name)
        for key in ("work_cell", "check_cell"):
            if key in p:
                cell(p[key])
    j = config["jobs"][job_name]
    keys(j, ["folder", "cover_file", "cover_profile", "cover_sheet", "systems", "documents"],
         ["folder", "cover_file", "cover_profile", "cover_sheet", "systems", "documents"], job_name)
    if j["cover_profile"] not in profiles:
        raise ValueError("表紙の帳票設定がありません")
    if not j["systems"] and not allow_unassigned:
        raise ValueError("社内AIに表紙のシステム行を設定してもらってください")
    ids, names, rows, targets = set(), set(), set(), set()
    for s in j["systems"]:
        keys(s, ["id", "name", "name_cell", "work_cell", "check_cell"],
             ["id", "name", "name_cell", "work_cell", "check_cell"], "システム")
        if not s["id"] or not s["name"] or s["id"] in ids or s["name"] in names:
            raise ValueError("システムID・名称は空欄不可、重複不可です")
        row = cell(s["name_cell"])[0]
        if row in rows:
            raise ValueError("同じ行に複数のシステムは設定できません")
        rows.add(row); ids.add(s["id"]); names.add(s["name"])
        for k in ("name_cell", "work_cell", "check_cell"):
            cell(s[k])
            if s[k] in targets:
                raise ValueError(f"表紙のセルが重複しています: {s[k]}")
            targets.add(s[k])
    seen, assigned = set(), set()
    if check_files:
        seen.add(source(j["folder"], j["cover_file"]))
    for d in j["documents"]:
        keys(d, ["file", "system", "role", "profile", "sheets"],
             ["file", "system", "role", "profile"], "書類")
        if d["system"] not in ids or d["role"] not in ROLES or d["profile"] not in profiles:
            raise ValueError(f"対応づけが不正です: {d['file']}")
        p = profiles[d["profile"]]
        if not all(p.get(k) for k in ("date_sheet", "work_cell", "check_cell")):
            raise ValueError(f"日付セルの設定が不足しています: {d['profile']}")
        validate_sheets(d.get("sheets", {}), d["file"])
        f = source(j["folder"], d["file"]) if check_files else d["file"]
        if f in seen:
            raise ValueError(f"ファイルの二重登録: {d['file']}")
        seen.add(f); assigned.add(d["system"])
    if assigned != ids and not allow_unassigned:
        raise ValueError(f"書類未登録のシステム: {', '.join(sorted(ids - assigned))}")
    return j

def ordered_systems(job):
    return sorted(job["systems"], key=lambda s: cell(s["name_cell"])[0])

def ordered_documents(job):
    order = {s["id"]: i for i, s in enumerate(ordered_systems(job))}
    return sorted(job["documents"], key=lambda d: (order[d["system"]], ROLES[d["role"]]))

def aggregate(records):
    result = {}
    for r in records:
        old = result.setdefault(r["system"], {"work": r["work"], "check": r["check"]})
        for k in ("work", "check"):
            old[k] = min(old[k], r[k])
    return result

def sheet_rules(profile, override):
    result = {name: dict(rule) for name, rule in profile.get("sheets", {}).items()}
    for name, rule in override.items():
        result.setdefault(name, {}).update(rule)
    return result

def parse_config_text(text):
    """Accept JSON or a single Markdown JSON code block, never execute text."""
    text = text.strip().lstrip("\ufeff")
    if text.startswith("```"):
        match = re.fullmatch(r"```(?:json)?\s*\n([\s\S]*?)\n```", text, re.IGNORECASE)
        if not match:
            raise ValueError("JSON部分だけを貼り付けてください")
        text = match.group(1)
    config = json.loads(text)
    keys(config, ["version", "profiles", "jobs"], ["version", "profiles", "jobs"], "設定")
    if config["version"] != 1 or set(config["jobs"]) != {"移行申請", "完了報告"}:
        raise ValueError("version=1、jobsには移行申請・完了報告の両方が必要です")
    # Allow an unfinished job while checking every populated job without local paths.
    for name, job in config["jobs"].items():
        keys(job, ["folder", "cover_file", "cover_profile", "cover_sheet", "systems", "documents"],
             ["folder", "cover_file", "cover_profile", "cover_sheet", "systems", "documents"], name)
        if not isinstance(job["systems"], list) or not isinstance(job["documents"], list):
            raise ValueError("systems / documents は配列です")
        validate(config, name, check_files=False, allow_unassigned=True)
        if job["cover_profile"] not in config["profiles"]:
            raise ValueError("全体表紙の帳票設定がありません")
    return config

def validate_general(plan, check_files=True):
    keys(plan, ["version", "layout", "output", "documents"], ["version", "layout", "output", "documents"], "一般出力")
    if plan["version"] != 1 or plan["layout"] not in ("existing", "a4") or plan["output"] not in ("combined", "individual"):
        raise ValueError("一般出力の設定値が不正です")
    if not isinstance(plan["documents"], list) or not plan["documents"]:
        raise ValueError("Excelファイルを追加してください")
    seen = set()
    for d in plan["documents"]:
        keys(d, ["file", "sheets"], ["file"], "一般出力のファイル")
        p = Path(d["file"])
        if not p.is_absolute() or p.suffix.lower() not in EXTENSIONS or p.name.startswith("~$"):
            raise ValueError(f"Excelの絶対パスを指定してください: {p}")
        p = p.resolve()
        if p in seen:
            raise ValueError(f"同じファイルが重複しています: {p}")
        if check_files and not p.is_file():
            raise ValueError(f"ファイルがありません: {p}")
        seen.add(p)
        validate_sheets(d.get("sheets", {}), str(p))
    return plan
