import copy
import json
from contextlib import contextmanager
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from core import parse_config_text, validate_general, read_json, digest
import excel_engine as engine
from test_pipeline import pdf, Book
from pypdf import PdfReader

BASE = Path(__file__).resolve().parents[1]

class GeneralTests(unittest.TestCase):
    def test_json_code_block_and_partial(self):
        config = read_json(BASE / "settings" / "example.json")
        config["jobs"]["移行申請"]["documents"] = []
        config["jobs"]["完了報告"]["documents"] = []
        text = json.dumps(config, ensure_ascii=False)
        self.assertEqual(parse_config_text("```json\n" + text + "\n```"), config)
        self.assertEqual(parse_config_text(text), config)

    def test_import_empty_template(self):
        config = {"version": 1, "profiles": {"p": {"sheets": {}}}, "jobs": {}}
        for name in ("移行申請", "完了報告"):
            config["jobs"][name] = {"folder": "", "cover_file": "", "cover_profile": "p", "cover_sheet": "", "systems": [], "documents": []}
        self.assertEqual(parse_config_text(json.dumps(config)), config)

    def test_import_rejects_unknown_keys_and_prose(self):
        config = read_json(BASE / "settings" / "example.json")
        config["run_code"] = "do not execute"
        with self.assertRaises(ValueError): parse_config_text(json.dumps(config))
        with self.assertRaises(ValueError): parse_config_text("説明文\n" + json.dumps(config))

    def test_general_validation(self):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / "book.xlsx"; p.write_bytes(b"original")
            plan = {"version": 1, "layout": "existing", "output": "combined", "documents": [{"file": str(p)}]}
            validate_general(plan)
            for key, bad in (("layout", "unknown"), ("output", "unknown"), ("documents", [])):
                broken = copy.deepcopy(plan); broken[key] = bad
                with self.assertRaises(ValueError): validate_general(broken)
            plan["documents"].append({"file": str(p)})
            with self.assertRaises(ValueError): validate_general(plan)

    def test_merge_existing_multi_page_landscape(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t); a, b = root / "a.pdf", root / "b.pdf"
            pdf(a, pages=2, width=841.89, height=595.28)
            pdf(b)
            self.assertEqual(engine.merge_pdf([a, b], root / "all.pdf", enforce_a4=False), 3)
            pages = PdfReader(root / "all.pdf").pages
            self.assertGreater(float(pages[0].mediabox.width), float(pages[0].mediabox.height))
            self.assertLess(float(pages[2].mediabox.width), float(pages[2].mediabox.height))

    def exercise_build(self, output, layout):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t); sources = []
            for n in ("folder_b", "folder_a"):
                folder = root / n; folder.mkdir()
                p = folder / "同名.xlsx"; p.write_bytes(n.encode())
                sources.append(p)
            hashes = [digest(p) for p in sources]
            plan = {"version": 1, "output": output, "layout": layout,
                    "documents": [{"file": str(p), "sheets": {"表紙": {"include": True}, "不要": {"include": False}}} for p in sources]}
            @contextmanager
            def fake_excel(): yield object()
            @contextmanager
            def fake_open(app, path): yield Book(path)
            def fake_prepare(book, rules, parts_dir, prefix, warnings, layout):
                self.assertFalse(rules["不要"]["include"])
                path = parts_dir / f"{prefix}.pdf"
                pdf(path, pages=2 if layout == "existing" else 1)
                return [path], ["表紙"]
            with patch.object(engine, "excel", fake_excel), patch.object(engine, "opened", fake_open), \
                 patch.object(engine, "prepare", fake_prepare), patch.object(engine, "value_at") as date_read:
                folder = Path(engine.build_general(plan, root / "out"))
                date_read.assert_not_called()
            audit = read_json(folder / "処理記録.json")
            self.assertEqual(audit["pages"], 4 if layout == "existing" else 2)
            self.assertEqual(len(audit["pdfs"]), 2 if output == "individual" else 1)
            self.assertEqual([r["file"] for r in audit["source_files"]], [str(p) for p in sources])
            self.assertEqual([Path(r["file"]).name for r in audit["print_plan"]], ["001_同名.xlsx", "002_同名.xlsx"])
            self.assertEqual([digest(p) for p in sources], hashes)
            self.assertNotIn("selected_dates", audit)
            self.assertFalse(list((root / "out").glob(".building_*")))

    def test_combined_existing(self): self.exercise_build("combined", "existing")
    def test_individual_existing(self): self.exercise_build("individual", "existing")
    def test_combined_a4(self): self.exercise_build("combined", "a4")
    def test_individual_a4(self): self.exercise_build("individual", "a4")

    def test_general_failure_cleanup(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t); src = root / "input.xlsx"; src.write_bytes(b"original")
            plan = {"version": 1, "layout": "existing", "output": "combined", "documents": [{"file": str(src)}]}
            with patch.object(engine, "excel", side_effect=RuntimeError("Excel unavailable")):
                with self.assertRaises(RuntimeError): engine.build_general(plan, root / "out")
            self.assertEqual(list((root / "out").iterdir()), [])
            self.assertEqual(src.read_bytes(), b"original")

    def test_prepare_existing_does_not_rewrite_page_settings(self):
        class Range:
            CountLarge = 1
            def __iter__(self): return iter([])
        class WS:
            Name = "表紙"; Visible = -1; ProtectContents = False
            def __init__(self):
                self.PageSetup = SimpleNamespace(PrintArea="A1:J40", PaperSize=8, Orientation=2, Zoom=80, PrintTitleRows="$1:$2")
            def Range(self, address): return Range()
            def ExportAsFixedFormat(self, **kwargs): pdf(Path(kwargs["Filename"]), pages=2)
        sheet = WS(); before = copy.deepcopy(vars(sheet.PageSetup))
        book = SimpleNamespace(Name="test.xlsx", Worksheets=[sheet], Save=lambda: None)
        with tempfile.TemporaryDirectory() as t, patch.object(engine, "blank_candidate", return_value=False):
            parts, names = engine.prepare(book, {}, Path(t), "001", [], layout="existing")
            self.assertEqual(names, ["表紙"]); self.assertEqual(len(parts), 1)
        self.assertEqual(vars(sheet.PageSetup), before)

    def test_print_general_cancel(self):
        from core import write_json
        with tempfile.TemporaryDirectory() as t:
            root = Path(t); src = root / "copy.xlsx"; src.write_bytes(b"copy")
            p = root / "001.pdf"; pdf(p)
            write_json(root / "処理記録.json", {"print_plan": [{"file": src.name, "sha256": digest(src), "sheets": ["表紙"]}],
                                               "pdfs": [{"file": p.name, "sha256": digest(p)}]})
            @contextmanager
            def fake_excel(): yield SimpleNamespace(Dialogs=lambda n: SimpleNamespace(Show=lambda: False))
            with patch.object(engine, "excel", fake_excel), patch.object(engine, "opened") as opened:
                self.assertIn("キャンセル", engine.print_result(root))
                opened.assert_not_called()

if __name__ == "__main__": unittest.main()
