import copy
import datetime as dt
from pathlib import Path
import tempfile
import unittest
from core import (aggregate, area, cell, ordered_documents, ordered_systems,
                  parse_date, read_json, serial, sheet_rules, source, validate)

BASE = Path(__file__).resolve().parents[1]

class Rules(unittest.TestCase):
    def setUp(self):
        self.config = read_json(BASE / "settings" / "example.json")

    def test_sample_contract(self):
        for name in ("移行申請", "完了報告"):
            validate(self.config, name, check_files=False)

    def test_minima_independent(self):
        a, b, c, d = [dt.date(2026, 11, day) for day in (5, 8, 3, 9)]
        result = aggregate([dict(system="A", work=a, check=b), dict(system="A", work=c, check=d)])
        self.assertEqual(result["A"], dict(work=c, check=b))

    def test_dates(self):
        for value in ("2026/11/2", "2026-11-02", "2026年11月2日", dt.datetime(2026, 11, 2, 13)):
            self.assertEqual(parse_date(value), dt.date(2026, 11, 2))

    def test_date_invalid(self):
        for value in (None, "", "11/2", "令和8年11月2日", "2026/11/2〜3", "2026/2/30", True, -1, float("nan"), 60):
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_date(value)

    def test_date_systems(self):
        for year in (1905, 2026, 2099):
            date = dt.date(year, 11, 2)
            for system in (False, True):
                self.assertEqual(parse_date(serial(date, system), system), date)
        self.assertEqual(parse_date(1), dt.date(1900, 1, 1))
        self.assertEqual(parse_date(0, True), dt.date(1904, 1, 1))

    def test_order(self):
        job = self.config["jobs"]["移行申請"]
        job["systems"].reverse(); job["documents"].reverse()
        self.assertEqual([s["id"] for s in ordered_systems(job)], ["system_a", "system_b"])
        self.assertEqual([(d["system"], d["role"]) for d in ordered_documents(job)],
                         [("system_a", "開発"), ("system_a", "運用"), ("system_b", "開発")])

    def test_same_role_stable(self):
        job = self.config["jobs"]["移行申請"]
        d = copy.deepcopy(job["documents"][0]); d["file"] = "追加.xlsx"
        job["documents"].append(d)
        self.assertEqual([d["file"] for d in ordered_documents(job)][:2], ["開発提出A.xlsx", "追加.xlsx"])

    def test_duplicate_document(self):
        job = self.config["jobs"]["移行申請"]
        job["documents"].append(copy.deepcopy(job["documents"][0]))
        with self.assertRaises(ValueError): validate(self.config, "移行申請", False)

    def test_missing_system_document(self):
        self.config["jobs"]["移行申請"]["documents"].pop()
        with self.assertRaises(ValueError): validate(self.config, "移行申請", False)

    def test_unknown_key(self):
        self.config["profiles"]["開発_申請様式A"]["workcell"] = "A1"
        with self.assertRaises(ValueError): validate(self.config, "移行申請", False)

    def test_target_collision(self):
        s = self.config["jobs"]["移行申請"]["systems"][0]
        s["check_cell"] = s["work_cell"]
        with self.assertRaises(ValueError): validate(self.config, "移行申請", False)

    def test_ranges(self):
        self.assertEqual(cell("XFD1048576"), (1048576, 16384))
        for bad in ("A0", "XFE1", "A1048577", "$A$1", "A1:B2"):
            with self.assertRaises(ValueError): cell(bad)
        for bad in ("B2:A1", "A1,B2", "Sheet1!A1"):
            with self.assertRaises(ValueError): area(bad)

    def test_relative_paths(self):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / "good.xlsx"; p.write_bytes(b"fake")
            self.assertEqual(source(t, "good.xlsx"), p.resolve())
            for bad in ("../bad.xlsx", str(p.resolve()), "missing.xlsx"):
                with self.assertRaises(ValueError): source(t, bad)

    def test_rule_merge(self):
        p = {"sheets": {"表紙": {"include": True, "area": "A1:F20", "entry_ranges": ["B5"]}}}
        r = sheet_rules(p, {"表紙": {"include": False}})
        self.assertFalse(r["表紙"]["include"])
        self.assertEqual(r["表紙"]["area"], "A1:F20")
        self.assertTrue(p["sheets"]["表紙"]["include"])

    def test_invalid_job(self):
        self.config["jobs"]["../bad"] = self.config["jobs"]["移行申請"]
        with self.assertRaises(ValueError): validate(self.config, "../bad", False)

if __name__ == "__main__": unittest.main()
