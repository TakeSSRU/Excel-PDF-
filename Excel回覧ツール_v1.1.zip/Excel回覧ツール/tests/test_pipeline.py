from contextlib import contextmanager
import datetime as dt
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from core import digest, read_json
import excel_engine as engine
from pypdf import PdfWriter, PdfReader

BASE = Path(__file__).resolve().parents[1]

def pdf(path, pages=1, width=595.28, height=841.89):
    writer = PdfWriter()
    for _ in range(pages): writer.add_blank_page(width=width, height=height)
    with open(path, "wb") as f: writer.write(f)
    writer.close()

class Cell:
    def __init__(self, address):
        self.Address = address; self.Value2 = None; self.NumberFormat = ""
        self.MergeArea = self
    def Cells(self, *args): return self

class Sheet:
    def __init__(self): self.cells = {}
    def Range(self, address): return self.cells.setdefault(address, Cell(address))

class Book:
    Date1904 = False
    def __init__(self, path):
        self.path = Path(path); self.sheet = Sheet()
    def Worksheets(self, _name): return self.sheet

class Pipeline(unittest.TestCase):
    def test_merge_order_and_count(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t); parts = [root / f"{i}.pdf" for i in range(3)]
            for p in parts: pdf(p)
            self.assertEqual(engine.merge_pdf(parts, root / "all.pdf"), 3)
            self.assertEqual(len(PdfReader(root / "all.pdf").pages), 3)

    def test_reject_multiple_pages(self):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / "bad.pdf"; pdf(p, pages=2)
            with self.assertRaises(ValueError): engine.merge_pdf([p], Path(t) / "all.pdf")

    def test_reject_wrong_paper(self):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / "bad.pdf"; pdf(p, width=841.89, height=595.28)
            with self.assertRaises(ValueError): engine.merge_pdf([p], Path(t) / "all.pdf")

    def fixture(self, root):
        config = read_json(BASE / "settings" / "example.json")
        j = config["jobs"]["移行申請"]; j["folder"] = str(root / "input")
        Path(j["folder"]).mkdir()
        for d in [{"file": j["cover_file"]}, *j["documents"]]:
            (Path(j["folder"]) / d["file"]).write_bytes(b"untouched workbook stand-in")
        return config

    def test_build_transaction_and_dates_with_fake_excel(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t); config = self.fixture(root); opened_books = {}
            original = {p.name: digest(p) for p in (root / "input").iterdir()}
            @contextmanager
            def fake_excel(): yield object()
            @contextmanager
            def fake_open(_app, path):
                b = Book(path); opened_books[Path(path).name] = b; yield b
            def fake_value(book, sheet, address):
                if book.path.name.startswith("000_"):
                    return {"B6": "システムA", "B7": "システムB"}[address]
                if "運用" in book.path.name:
                    return "2026/11/3" if address == "H12" else "2026/11/9"
                return "2026/11/5" if address == "F8" else "2026/11/8"
            def fake_prepare(book, rules, dest, prefix, warnings):
                p = dest / (prefix + ".pdf"); pdf(p)
                book.path.write_bytes(book.path.read_bytes() + b" prepared")
                return [p], [next(iter(rules))]
            with patch.object(engine, "excel", fake_excel), patch.object(engine, "opened", fake_open), \
                 patch.object(engine, "value_at", fake_value), patch.object(engine, "prepare", fake_prepare):
                out = Path(engine.build(config, "移行申請", root / "out"))
            audit = read_json(out / "処理記録.json")
            self.assertEqual(audit["pages"], 4)
            self.assertEqual(audit["selected_dates"]["system_a"], {"work": "2026-11-03", "check": "2026-11-08"})
            self.assertEqual([Path(p["file"]).name[:3] for p in audit["print_plan"]], ["000", "001", "002", "003"])
            self.assertEqual(original, {p.name: digest(p) for p in (root / "input").iterdir()})
            self.assertFalse(list((root / "out").glob(".building_*")))
            self.assertIsNotNone(opened_books["000_全体表紙.xlsx"].sheet.cells["E6"].Value2)

    def test_failure_cleans_partial_output(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t); config = self.fixture(root)
            with patch.object(engine, "excel", side_effect=RuntimeError("Excel unavailable")):
                with self.assertRaises(RuntimeError): engine.build(config, "移行申請", root / "out")
            self.assertEqual(list((root / "out").iterdir()), [])
            self.assertEqual(len(list((root / "input").iterdir())), 4)

    def test_print_detects_tampering_before_excel(self):
        from core import write_json
        with tempfile.TemporaryDirectory() as t:
            root = Path(t); p = root / "copy.xlsx"; p.write_bytes(b"before")
            write_json(root / "処理記録.json", {"print_plan": [{"file": "copy.xlsx", "sha256": digest(p)}]})
            p.write_bytes(b"changed")
            with patch.object(engine, "excel") as excel:
                with self.assertRaises(ValueError): engine.print_result(root)
                excel.assert_not_called()

    def test_blank_ranges_keep_zero(self):
        class WS:
            def Range(self, address): return SimpleNamespace(CountLarge=1, Value2=0 if address == "A1" else "")
        self.assertFalse(engine.blank_candidate(WS(), {"entry_ranges": ["A1"]}))
        self.assertTrue(engine.blank_candidate(WS(), {"entry_ranges": ["B1"]}))

if __name__ == "__main__": unittest.main()
