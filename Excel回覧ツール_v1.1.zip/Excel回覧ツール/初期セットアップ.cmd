@echo off
cd /d "%~dp0"
py -3.11 -m venv .venv
if errorlevel 1 goto failed
if exist "wheels\*.whl" (
  ".venv\Scripts\python.exe" -m pip install --no-index --find-links=wheels -r requirements.txt
) else (
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
)
if errorlevel 1 goto failed
echo Setup complete. Run the launcher.
pause
exit /b 0
:failed
echo Setup failed. See README.md. Python 3.11 and approved packages are required.
pause
exit /b 1
